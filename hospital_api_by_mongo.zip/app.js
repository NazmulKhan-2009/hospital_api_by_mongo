require('dotenv').config()
const express = require('express')
const connection=require('./db.con')
const app=express()
const port=5000 ||  process.env.PORT 
const hospitalRoute=require('./src/router/hospitalData')


connection()



app.use(express.json())


app.use('/hospital',hospitalRoute)





app.get('/',(req,res)=>{
 res.send(`<h1>Welcome to the hospital REST API at ${new Date().toLocaleDateString()}</h1>`)
})
app.listen(5000,()=>console.log(`Server Ready from ${port}`))